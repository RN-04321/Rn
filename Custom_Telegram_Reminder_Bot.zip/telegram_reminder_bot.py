import time
import telegram

# Aapka provided Telegram Bot Token aur Chat ID
BOT_TOKEN = '7756235656:AAH8WFzmG4iE6jMXhp8VzNZCDA_k9C_6_WA'
CHAT_ID = '7196336708'

bot = telegram.Bot(token=BOT_TOKEN)

reminders = [
    "🛑 Stop Loss Limit Cross Hone Wala Hai! Game band kar do!",
    "✅ Target Multiplier Achieved! Ab withdraw karo.",
    "⚡️ Safe Multiplier 1.5x tak pahucha. Withdraw karne ka samay hai.",
    "📊 Aaj ki game session me disciplined khelte raho."
]

def send_reminder():
    for message in reminders:
        bot.send_message(chat_id=CHAT_ID, text=message)
        time.sleep(10)

if __name__ == '__main__':
    while True:
        send_reminder()
        time.sleep(60 * 30)
